# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from .usage import Usage
from .._models import BaseModel
from .interaction import Interaction

__all__ = ["InteractionCompletedEvent", "Metadata"]


class Metadata(BaseModel):
    """Optional metadata accompanying ANY streamed event."""

    usage: Optional[Usage] = None
    """Statistics on the interaction request's token usage."""


class InteractionCompletedEvent(BaseModel):
    event_type: Literal["interaction.completed"]

    interaction: Interaction
    """Required.

    The completed interaction with empty outputs to reduce the payload size. Use the
    preceding ContentDelta events for the actual output.
    """

    event_id: Optional[str] = None
    """
    The event_id token to be used to resume the interaction stream, from this event.
    """

    metadata: Optional[Metadata] = None
    """Optional metadata accompanying ANY streamed event."""
