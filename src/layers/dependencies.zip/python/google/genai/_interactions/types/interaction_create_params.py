# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List, Union, Iterable
from typing_extensions import Literal, Required, TypeAlias, TypedDict

from .step_param import StepParam
from .tool_param import ToolParam
from .model_param import ModelParam
from .content_param import ContentParam
from .environment_param import EnvironmentParam
from .text_content_param import TextContentParam
from .audio_content_param import AudioContentParam
from .image_content_param import ImageContentParam
from .video_content_param import VideoContentParam
from .webhook_config_param import WebhookConfigParam
from .document_content_param import DocumentContentParam
from .generation_config_param import GenerationConfigParam
from .dynamic_agent_config_param import DynamicAgentConfigParam
from .text_response_format_param import TextResponseFormatParam
from .audio_response_format_param import AudioResponseFormatParam
from .image_response_format_param import ImageResponseFormatParam
from .deep_research_agent_config_param import DeepResearchAgentConfigParam

__all__ = [
    "BaseCreateModelInteractionParams",
    "Input",
    "Environment",
    "ResponseFormat",
    "ResponseFormatResponseFormatList",
    "BaseCreateAgentInteractionParams",
    "AgentConfig",
    "CreateModelInteractionParamsNonStreaming",
    "CreateModelInteractionParamsStreaming",
    "CreateAgentInteractionParamsNonStreaming",
    "CreateAgentInteractionParamsStreaming",
]


class BaseCreateModelInteractionParams(TypedDict, total=False):
    api_version: str

    input: Required[Input]
    """The input for the interaction."""

    model: Required[ModelParam]
    """The name of the `Model` used for generating the interaction."""

    background: bool
    """Input only. Whether to run the model interaction in the background."""

    environment: Environment
    """The environment configuration for the interaction.

    Can be an object specifying remote environment sources or a string referencing
    an existing environment ID.
    """

    generation_config: GenerationConfigParam
    """Input only. Configuration parameters for the model interaction."""

    previous_interaction_id: str
    """The ID of the previous interaction, if any."""

    response_format: ResponseFormat
    """
    Enforces that the generated response is a JSON object that complies with the
    JSON schema specified in this field.
    """

    response_mime_type: str
    """The mime type of the response. This is required if response_format is set."""

    response_modalities: List[Literal["text", "image", "audio", "video", "document"]]
    """The requested modalities of the response (TEXT, IMAGE, AUDIO)."""

    service_tier: Literal["flex", "standard", "priority"]
    """The service tier for the interaction."""

    store: bool
    """Input only. Whether to store the response and request for later retrieval."""

    system_instruction: str
    """System instruction for the interaction."""

    tools: Iterable[ToolParam]
    """A list of tool declarations the model may call during interaction."""

    webhook_config: WebhookConfigParam
    """Optional.

    Webhook configuration for receiving notifications when the interaction
    completes.
    """


Input: TypeAlias = Union[
    str,
    Iterable[StepParam],
    Iterable[ContentParam],
    TextContentParam,
    ImageContentParam,
    AudioContentParam,
    DocumentContentParam,
    VideoContentParam,
]

Environment: TypeAlias = Union[str, EnvironmentParam]

ResponseFormatResponseFormatList: TypeAlias = Union[
    AudioResponseFormatParam, TextResponseFormatParam, ImageResponseFormatParam, object
]

ResponseFormat: TypeAlias = Union[
    Iterable[ResponseFormatResponseFormatList],
    AudioResponseFormatParam,
    TextResponseFormatParam,
    ImageResponseFormatParam,
    object,
]


class BaseCreateAgentInteractionParams(TypedDict, total=False):
    api_version: str

    agent: Required[
        Union[
            Literal[
                "deep-research-pro-preview-12-2025",
                "deep-research-preview-04-2026",
                "deep-research-max-preview-04-2026",
            ],
            str,
        ]
    ]
    """The name of the `Agent` used for generating the interaction."""

    input: Required[Input]
    """The input for the interaction."""

    agent_config: AgentConfig
    """Configuration parameters for the agent interaction."""

    background: bool
    """Input only. Whether to run the model interaction in the background."""

    environment: Environment
    """The environment configuration for the interaction.

    Can be an object specifying remote environment sources or a string referencing
    an existing environment ID.
    """

    previous_interaction_id: str
    """The ID of the previous interaction, if any."""

    response_format: ResponseFormat
    """
    Enforces that the generated response is a JSON object that complies with the
    JSON schema specified in this field.
    """

    response_mime_type: str
    """The mime type of the response. This is required if response_format is set."""

    response_modalities: List[Literal["text", "image", "audio", "video", "document"]]
    """The requested modalities of the response (TEXT, IMAGE, AUDIO)."""

    service_tier: Literal["flex", "standard", "priority"]
    """The service tier for the interaction."""

    store: bool
    """Input only. Whether to store the response and request for later retrieval."""

    system_instruction: str
    """System instruction for the interaction."""

    tools: Iterable[ToolParam]
    """A list of tool declarations the model may call during interaction."""

    webhook_config: WebhookConfigParam
    """Optional.

    Webhook configuration for receiving notifications when the interaction
    completes.
    """


AgentConfig: TypeAlias = Union[DynamicAgentConfigParam, DeepResearchAgentConfigParam]


class CreateModelInteractionParamsNonStreaming(BaseCreateModelInteractionParams, total=False):
    stream: Literal[False]
    """Input only. Whether the interaction will be streamed."""


class CreateModelInteractionParamsStreaming(BaseCreateModelInteractionParams):
    stream: Required[Literal[True]]
    """Input only. Whether the interaction will be streamed."""


class CreateAgentInteractionParamsNonStreaming(BaseCreateAgentInteractionParams, total=False):
    stream: Literal[False]
    """Input only. Whether the interaction will be streamed."""


class CreateAgentInteractionParamsStreaming(BaseCreateAgentInteractionParams):
    stream: Required[Literal[True]]
    """Input only. Whether the interaction will be streamed."""


InteractionCreateParams = Union[
    CreateModelInteractionParamsNonStreaming,
    CreateModelInteractionParamsStreaming,
    CreateAgentInteractionParamsNonStreaming,
    CreateAgentInteractionParamsStreaming,
]
