# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._types import SequenceNotStr, Base64FileInput
from .._utils import PropertyInfo
from .._models import set_pydantic_config

__all__ = ["GoogleSearchCallStepParam", "Arguments"]


class Arguments(TypedDict, total=False):
    """Required. The arguments to pass to Google Search."""

    queries: SequenceNotStr[str]
    """Web search queries for the following-up web search."""


class GoogleSearchCallStepParam(TypedDict, total=False):
    """Google Search call step."""

    id: Required[str]
    """Required. A unique ID for this specific tool call."""

    arguments: Required[Arguments]
    """Required. The arguments to pass to Google Search."""

    type: Required[Literal["google_search_call"]]

    search_type: Literal["web_search", "image_search", "enterprise_web_search"]
    """The type of search grounding enabled."""

    signature: Annotated[Union[str, Base64FileInput], PropertyInfo(format="base64")]
    """A signature hash for backend validation."""


set_pydantic_config(GoogleSearchCallStepParam, {"arbitrary_types_allowed": True})
